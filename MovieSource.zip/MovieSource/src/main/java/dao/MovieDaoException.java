package dao;

public class MovieDaoException extends Exception {

    public MovieDaoException(final String message) {
        super(message);
    }
}
