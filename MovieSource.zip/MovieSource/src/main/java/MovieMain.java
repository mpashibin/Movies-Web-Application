import model.Movie;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import utility.WorkbookUtility;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class MovieMain {

    public final static String INPUT_FILE = "src\\main\\webapp\\assets\\movies.xlsx";

    public static void main(String[] args) {

        final File inputFile = new File(INPUT_FILE);

    }

}
