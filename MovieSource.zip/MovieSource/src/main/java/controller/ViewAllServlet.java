package controller;

import java.io.*;
import java.util.Collections;
import java.util.List;

import comparator.LengthComparator;
import comparator.TitleComparator;
import dao.MovieDao;
import dao.MovieDaoException;
import dao.MovieDaoImpl;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.ServletException;
import model.Movie;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import utility.WorkbookUtility;

@WebServlet(name = "ViewAllServlet", urlPatterns = "/ViewAll" )
public class ViewAllServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String target = "/view-all.jsp";

        // Get access to our spreadsheet
        // final String filePath = getServletContext().getRealPath(WorkbookUtility.INPUT_FILE);
        // final File inputFile = new File(filePath);

        // Fetch the information and use it to populate the model
        try {
            // final List<Movie> movies = WorkbookUtility.retrieveMoviesFromWorkbook(inputFile);

            final MovieDao movieDao = new MovieDaoImpl();
            final List<Movie> movies = movieDao.retrieveMovies();

            String sortType = request.getParameter("sortType");

            if (null != sortType && sortType.equals("title")) {
                Collections.sort(movies, new TitleComparator());
            } else if (null != sortType && sortType.equals("length")) {
                Collections.sort(movies, new LengthComparator());
            }

            // Attach the model to the request
            request.setAttribute("movies", movies);

        } catch (MovieDaoException e) {
            e.printStackTrace();
        }
        // Forward the request to the view
        getServletContext().getRequestDispatcher(target).forward(request, response);
    }

}