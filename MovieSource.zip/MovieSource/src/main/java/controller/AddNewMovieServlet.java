package controller;


import java.io.*;

import com.google.common.base.Strings;
import dao.MovieDao;
import dao.MovieDaoException;
import dao.MovieDaoImpl;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.ServletException;
import model.Movie;

@WebServlet(name = "AddNewMovieServlet", urlPatterns = "/AddNewMovie")
public class AddNewMovieServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Get the information submitted by the user
        try {
            final String title = request.getParameter("title");
            final String director = request.getParameter("director");
            final String lengthInMinutesString = request.getParameter("lengthInMinutes");

            if(Strings.isNullOrEmpty(title)
                    || Strings.isNullOrEmpty(director)
                    || Strings.isNullOrEmpty(lengthInMinutesString)) {

                // User did not submit all the necessary information
                request.setAttribute("message", "You must complete all fields to submit the form.");

            } else {
                // User submitted all the necessary info
                final int lengthInMinutes = Integer.parseInt(lengthInMinutesString);

                final MovieDao movieDao = new MovieDaoImpl();

                // Create person object using the submitted info
                final Movie movie = new Movie(title, director, lengthInMinutes);

                // Insert that person object into the db using movieDao
                movieDao.insertMovie(movie);
                request.setAttribute("message", "The movie was added.");
            }
        } catch (MovieDaoException e) {
            e.printStackTrace();
            request.setAttribute("message", e.getMessage());
        }

        getServletContext().getRequestDispatcher("/add-movie.jsp").forward(request, response);

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

}