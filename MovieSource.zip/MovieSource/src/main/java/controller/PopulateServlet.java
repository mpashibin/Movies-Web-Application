package controller;

import java.io.*;

import dao.MovieDao;
import dao.MovieDaoException;
import dao.MovieDaoImpl;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.ServletException;
import utility.WorkbookUtility;

@WebServlet(name = "PopulateServlet", urlPatterns = "/Populate")
public class PopulateServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        final String filePath = request.getServletContext().getRealPath(WorkbookUtility.INPUT_FILE);

        final MovieDao movieDao = new MovieDaoImpl();

        String message = "";

        try {
            movieDao.populate(filePath);
            message = "The database was successfully populated.";
        } catch (MovieDaoException e) {
            e.printStackTrace();
            message = "There was an error, the database was not populated.";
        }

        request.setAttribute("message", message);
        getServletContext().getRequestDispatcher("/populate.jsp").forward(request, response);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

}