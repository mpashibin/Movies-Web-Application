package controller;

import java.io.*;
import java.util.List;
import java.util.stream.Collectors;

import dao.MovieDao;
import dao.MovieDaoException;
import dao.MovieDaoImpl;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.ServletException;
import model.Movie;

@WebServlet(name = "SearchServlet", value = "SearchServlet")
public class SearchServlet extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Get access to our spreadsheet
        // final String filePath = getServletContext().getRealPath(WorkbookUtility.INPUT_FILE);
        // final File inputFile = new File(filePath);

        // Fetch the list of people
        try {
            // final List<Movie> movies = WorkbookUtility.retrieveMoviesFromWorkbook(inputFile);

            final MovieDao movieDao = new MovieDaoImpl();
            final List<Movie> movies = movieDao.retrieveMovies();

            // Search parameters

            String titleFilter = request.getParameter("title");
            String directorFilter = request.getParameter("director");

            List<Movie> filteredMovies = movies;

            // Apply filters if user requests

            if (titleFilter != null && !titleFilter.isEmpty()) {
                filteredMovies = filteredMovies.stream()
                        .filter(movie -> movie.getTitle().equalsIgnoreCase(titleFilter))
                        .collect(Collectors.toList());
            }

            if (directorFilter != null && !directorFilter.isEmpty()) {
                filteredMovies = filteredMovies.stream()
                        .filter(movie -> movie.getDirector().equalsIgnoreCase(directorFilter))
                        .collect(Collectors.toList());
            }

            // Attach the filtered list to the request
            request.setAttribute("movies", filteredMovies);

        } catch (MovieDaoException e) {
            e.printStackTrace();
        }

        // Forward the request to the view
        getServletContext().getRequestDispatcher("/view-all.jsp").forward(request, response);
    }
}